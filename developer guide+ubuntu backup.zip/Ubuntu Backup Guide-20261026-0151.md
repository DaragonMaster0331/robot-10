# Ubuntu Backup Guide

**User:** Anonymous  
**Created:** 10/26/2026 1:44:51  
**Updated:** 10/26/2026 1:50:45  
**Exported:** 10/26/2026 1:51:42  
**Link:** [https://chatgpt.com/c/6adf1302-de4c-83ea-a274-a5b7088fe648](https://chatgpt.com/c/6adf1302-de4c-83ea-a274-a5b7088fe648)  

## Prompt:
10/26/2026, 1:46:01 AM

You explain about the method how to backup the ubuntu 22.04 system on the Jetson Orin Nano in very very detail step by step

## Response:
10/26/2026, 1:46:06 AM · gpt-6-mini

> **Searched 7 websites**
>
> 
>
> Worked for 20s

# Complete step-by-step guide: Back up Ubuntu 22.04 on a Jetson Orin Nano

I will explain this from the beginning, including what a backup is, which method to choose, the commands to type, how to verify your backup, and how to restore the system if something goes wrong.

Our goal is to protect your **Jetson Orin Nano running Ubuntu 22.04**, including the operating system, installed packages, Python environments, robot SDKs, configuration files, and your own development projects.

## 1\. First, understand what we are backing up
[![NVIDIA Jetson Orin Nano: Der ultimative Leitfaden für Steckverbinder und Funktionen](https://images.openai.com/static-rsc-4/kfwnLukogTjabitG43TRk_XCDL0z-YAkHbgwO4yD8XHb73Ml-4wH_pphkJNABqVYZ9mES8Ql9-sTc7IrLqPkB8YHzVQ6-GY5uBw2iFcTIB_TSWdQFPYUarI7rawvPMbyeicv--8g7ZLM7wcYL39ZFfKDqIRBERauuXuMK8x0vjsXdXpPPDcJABvSo0hCydNI?purpose=fullsize)](https://de.linkedin.com/pulse/nvidia-jetson-orin-nano-ultimate-guide-connectors-ummadisetti-oeovc?tl=de)

[![Jetson Orin NanoをUSB接続のSSDから起動する](https://images.openai.com/static-rsc-4/Agc2Wyd0QBC70yCBzAgauZSR6kUOcpp0h4GKpeGiBiLAdxi1ZO8zml9nybx8XgUQc9k4AmFewsu-8a54AZUzPxMGLhTVJUjNhXeQFHWsCJ1P7EDJum6dq_k4773ofLv60SR4q6-SDwb6t46RGRhD1ZN3ybq_7GrgksEJvY8-eCCwRBeLKFwWUWyF7vVV8zev?purpose=fullsize)](https://zenn.dev/tiryoh/articles/2025-05-29-jetson-orin-nano-usb-ssd)

[![Jetson Orin Nano Not Detected by Ubuntu 22 via USB in Recovery Mode - Jetson Orin Nano - NVIDIA Developer Forums](https://images.openai.com/static-rsc-4/hT5tFsWwAusx0vY7-eGkCnCFsszIThDCzfVNcSbDq3OVv7r7af7j7nJljMHgpBDZqXj2NopSofy0_w6xkhTZ1ztucKKHJws60md4joMjddUlZgBETKCGcazV7oOIQCxKI0OOrNnK0b6jcYlFW64q1_8OijONYMSKDuwYScb-KaPMIq06cTQvpGeweT7yvapy?purpose=fullsize)](https://forums.developer.nvidia.com/t/jetson-orin-nano-not-detected-by-ubuntu-22-via-usb-in-recovery-mode/286259)

[![Waveshare NVIDIA Jetson Orin Nano AI Development Board 4GB](https://images.openai.com/static-rsc-4/xefi92DlDfeSTRha5smeOXw26ExiJUgmbwXd5-2qWB1x_ynafhYHDwV-mmnRAx2b740OOcTg9Ka4GM206VS0XMifgw57cP37rZlQCFB5rC96CwFFPLaU-FFAPr_3rKLqGTj_a5qN7m_cyR4GtanHQs1pCKduq9CSPBEbsnywCQBc6tHDa6kI5GUFtHZcP6xm?purpose=fullsize)](https://www.geekbuying.com/item/Waveshare-NVIDIA-Jetson-Orin-Nano-AI-development-Board-4GB-521196.html)

[![Quick Start Guide — Jetson Orin Nano Developer Kit - User Guide](https://images.openai.com/static-rsc-4/1Pich7u2bIafQMOhEm3h8uOGAS1myj4QCTR19uDUGtI4joHK8RY4rqVKYGjM8KbNEKM-Y8KaJFfbxI-xzfnk836HhhcmO_wftVAOUAz6-U6WT85aihIXGT8KbsdQglK-DnU6aKemAcUHVfQE7sMbM5E8Tuz1D0dtpdTSPWWqCzgSw62IKpkPWdKNRJUr6j1p?purpose=fullsize)](https://docs.nvidia.com/jetson/orin-nano-devkit/user-guide/quick_start.html)

[![Kiwi + Jetson Orin Nano Super Kit | Cytrence](https://images.openai.com/static-rsc-4/UpD4_MnniEVySbkxeghRdMWG-ce37CXhBb6swIvac9FrNAei6NHoH_gmuj8CDNVuROuIE_DvNcEPUEtatN4ck9kIB-iZIuZQE3_eEA2zn-FZijQ8XEnoXEAqTyfRr3p1gfPyy9zVa5qCJyHt8BMJR0x6XEG3nl8UMbyi0qL7p1okprtI_hQbadFHOXd2Ae1m?purpose=fullsize)](https://www.cytrence.com/product-page/kiwi-pro-jetson-orin-nano-super-kit)

Your Jetson is a small computer. Like a desktop PC, it has several types of information that may need to be backed up.

| Component | What it contains | Should we back it up? |
|--------|--------|--------|
| Ubuntu operating system | Linux system files and configuration | Yes |
| Installed software | CMake, GCC, libraries and utilities | Yes |
| Python environments | Python packages and virtual environments | Yes |
| Robot development files | SDKs, source code, models and scripts | Yes |
| Network configuration | IP addresses, Wi-Fi and network settings | Yes, securely |
| User files | Documents, downloads and project folders | Yes |
| Boot firmware and boot configuration | Files required to start the Jetson | Important; method-dependent |

There is one important distinction: **backing up your files is not the same as backing up the entire system.**

For example, copying your robot project to an external drive will not necessarily let you recover Ubuntu if the operating system becomes corrupted.

For good protection, I recommend a combination of a system-level recovery backup and a separate backup of your development files.

## 2\. Choose the right backup method

The Jetson Orin Nano can use different storage and recovery arrangements, so we should not immediately run a command that copies an entire disk.

[![Generic x86-64 - Home Assistant](https://images.openai.com/static-rsc-4/vNMHhBG_1_AdBJR83-4ai_OCBV6bGHfdrMuvSf1kr8QHElndgrn652BHefMQEzovWLD70loFEAdROXaB88-QFomyXf0JK0wMfRECrxUVt3vsezmqt8OXJUXvV6_jSYz4DGSBUbp3uYsAhQz-Wbgby14MP-57Ifud5e2Gzy_atizm_sII49w6oxi6eI4V2wOK?purpose=fullsize)](https://www.home-assistant.io/installation/generic-x86-64/)

**Method A - File-level backup**

(Recommended starting point)

Copies your home directory, development projects, configuration files and package information to an external drive. Straightforward, but does not create a complete bootable system image.

---

[![Quick Start Guide — Jetson Orin Nano Developer Kit - User Guide](https://images.openai.com/static-rsc-4/1Pich7u2bIafQMOhEm3h8uOGAS1myj4QCTR19uDUGtI4joHK8RY4rqVKYGjM8KbNEKM-Y8KaJFfbxI-xzfnk836HhhcmO_wftVAOUAz6-U6WT85aihIXGT8KbsdQglK-DnU6aKemAcUHVfQE7sMbM5E8Tuz1D0dtpdTSPWWqCzgSw62IKpkPWdKNRJUr6j1p?purpose=fullsize)](https://docs.nvidia.com/jetson/orin-nano-devkit/user-guide/quick_start.html)

**Method B - Full storage image**

Creates an image of the storage device, such as a microSD card. This can preserve partitions and system data when captured correctly. Restoring it may overwrite the destination device, and it does not automatically capture firmware stored elsewhere.

---

[![Kiwi + Jetson Orin Nano Super Kit | Cytrence](https://images.openai.com/static-rsc-4/UpD4_MnniEVySbkxeghRdMWG-ce37CXhBb6swIvac9FrNAei6NHoH_gmuj8CDNVuROuIE_DvNcEPUEtatN4ck9kIB-iZIuZQE3_eEA2zn-FZijQ8XEnoXEAqTyfRr3p1gfPyy9zVa5qCJyHt8BMJR0x6XEG3nl8UMbyi0qL7p1okprtI_hQbadFHOXd2Ae1m?purpose=fullsize)](https://www.cytrence.com/product-page/kiwi-pro-jetson-orin-nano-super-kit)

**Method C - NVIDIA recovery and re-flashing**

Uses NVIDIA's Jetson Linux tools on a separate Ubuntu host PC to reinstall the appropriate system image. This is important for deeper recovery, particularly when boot firmware or boot partitions need to be restored.

**My recommendation\:** use Method A immediately to protect your valuable files, then choose Method B or C based on how your Jetson is installed.

Before you begin, we need to identify whether your Ubuntu system boots from a microSD card or an NVMe SSD. That determines the safest full-system backup procedure.

## 3\. Step 1 - Check your Jetson before making the backup

We will first inspect the system without changing anything.

### 3.1 Open the Ubuntu Terminal

On your Jetson Orin Nano\:

1. Log in to Ubuntu.
2. Open the Terminal application.
3. You should see a command prompt similar to\:

```bash
username@jetson:~$
```

You can also press `Ctrl + Alt + T` to open a terminal.

**Important\:** In the commands below, type only the command inside each code block. Do not type the `$` shown in examples of terminal prompts.

### 3.2 Confirm the Ubuntu version

Run\:

```bash
cat /etc/os-release
```

Look for\:

```text
PRETTY_NAME="Ubuntu 22.04..."
VERSION_ID="22.04"
```

This tells you which Ubuntu release is installed.

### 3.3 Check the Jetson software version

Run\:

```bash
cat /etc/nv_tegra_release
```

On an NVIDIA Jetson Linux installation, this often shows a release identifier such as `R36` or `R35`\.

You can also run\:

```bash
dpkg-query -W nvidia-l4t-core
```

This helps identify the installed NVIDIA Linux release, although the command may not work on every Ubuntu image.

Why is this important? A Jetson system is more than ordinary Ubuntu. NVIDIA's Jetson Linux includes the kernel, NVIDIA drivers, boot firmware and other platform-specific components. A generic Ubuntu installation image alone is not necessarily enough to reconstruct your existing robot development environment. \[[Jetson Linux](https://developer.nvidia.com/embedded/jetson-linux-r3640?utm_source=chatgpt.com); [Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com)\]

### 3.4 Identify the storage device that contains Ubuntu

Run\:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

Example output might look like this\:

```text
NAME         SIZE TYPE FSTYPE MOUNTPOINTS MODEL
mmcblk0     119G disk
├─mmcblk0p1  118G part ext4   /
nvme0n1     477G disk
└─nvme0n1p1  477G part ext4   /mnt/data
```

This is only an example; your actual output may be different.

How to read it\:

- `NAME`\: device or partition name.
- `SIZE`\: storage capacity.
- `TYPE`\: whether it is a disk or partition.
- `FSTYPE`\: filesystem type, such as `ext4`\.
- `MOUNTPOINTS`\: where the partition is mounted.
- `MODEL`\: hardware model, when available.
- `/`\: the root filesystem containing your running Ubuntu system.

In this example, Ubuntu is running from a microSD card represented by `mmcblk0`, while an NVMe SSD is mounted separately at `/mnt/data`\.

If you see `/dev/nvme0n1p1` mounted at `/`, Ubuntu is instead running from an NVMe SSD partition.

**Do not assume that `mmcblk0` or `nvme0n1` is your system disk without checking the output.**

### 3.5 Check how much data needs to be protected

Run\:

```bash
df -h /
```

Then\:

```bash
df -h /home
```

Example\:

```text
Filesystem      Size  Used Avail Use% Mounted on
/dev/mmcblk0p1  116G   42G   69G  38% /
```

Here, `Used` is approximately 42 GB. That gives you an initial idea of how much data the system contains.

However, the backup may require more space than your current used storage if you create a full-device image, because a raw image can include unused space too.

### 3.6 Check where your personal and development files are located

Run\:

```bash
echo "$HOME"
```

For example\:

```text
/home/username
```

Then inspect the directory\:

```bash
ls -lah "$HOME"
```

Look for folders containing your work, such as\:

```text
Documents
Downloads
Projects
robot_ws
unitree_sdk2
models
```

These are examples, not folders that every Jetson must have.

Make a note of any important project folders outside your home directory as well. Robot software is sometimes installed in `/opt`, `/usr/local`, or other locations.

---

## 4\. Step 2 - Prepare an external backup drive

You need somewhere separate to store your backup.

I recommend an external USB SSD or hard drive with enough free space. A 256 GB or larger drive may be suitable for a modest installation, but check your actual data size before buying or using one.

[![ADATA SE880 - USB Type-C External SSD in Grey - 500 GB - Clove Technology](https://images.openai.com/static-rsc-4/VbnTsk68LTbJViXOgCjBut9WFJSTdILIXFT_e4AakTJ_kG5oCuS85XS_JGecH8H7zn1ao8J9A75Pbksr6C-k1oK7XIuJkYvu-uc214JliiOVAHyvT9I_5uSLnb63bMCrw5WOfOiiuec4o0nv6Z3isyxlj8TM9XBoV21vbtwxHL_SweOrsJpRG1rxLvNIaDWM?purpose=fullsize)](https://www.clove.co.uk/products/adata-se880-500-gb-wi-fi-grey?srsltid=AfmBOoo_V1892OSMA2aGPaUVkWwy9pZJjLe60C2MTaDAlth5Z8rZW4Sr)

**Preferred: external SSD**

Fast, convenient and useful for repeated backups. Choose a capacity based on your current system usage and expected growth.

[![HD 500Gb Externo com cabo USB 3.0](https://images.openai.com/static-rsc-4/U_E1-DfFJEhw36PoMqbSytkwMge0HywOd48m2cBLvuyxCp4wdi1cDXcOGMHG6-XUmEUaK0Ao7T9maYgDLQ-Pdx1886f2lcnUfj_ZI3O0yCMNdVyik9oYi5Og2fqxb42GlTY6eTuU5U4xPlkWhUAPt8y0gb_Te0Zdu0pnSVcek7bgs8tnPZExZQ1J2VMJd7j7?purpose=fullsize)](https://www.expressinformatica.net/hd-500gb-externo-com-cabo-usb-3-0-slim-expansion-stea500400-seagate)

**Alternative: external HDD**

Often economical for large backups, although usually slower than an SSD.

### 4.1 Connect the external drive

1. Connect the USB drive to your Jetson.
2. Wait several seconds.
3. Open Ubuntu's file manager.
4. Find the external drive in the sidebar.
5. Click it to mount it.

Ubuntu may mount the drive under a path similar to\:

```text
/media/username/BackupDrive
```

The actual path depends on your username and the drive's volume label.

### 4.2 Find the exact mount point

Run\:

```bash
lsblk -f
```

Look for the external drive and its `MOUNTPOINTS` column.

You can also run\:

```bash
df -hT
```

This displays mounted filesystems, their types, sizes and available space.

**Do not proceed until you can identify which mount point belongs to the external backup drive.**

### 4.3 Understand the filesystem choice

For a Linux system backup, an `ext4`\-formatted external drive is a good choice because it supports Linux file permissions, ownership and other metadata.

NTFS and exFAT may be convenient when sharing the drive with Windows, but they do not preserve all Linux filesystem properties in the same way. For a metadata-preserving system backup, ext4 is generally preferable.

Be careful: formatting a drive erases its existing contents. Do not format it unless you have confirmed that you have no data on it that you need to keep.

### 4.4 Create a backup directory

For the following example, assume your external drive is mounted at\:

```text
/media/username/BackupDrive
```

Replace that example path with the exact path from your Jetson.

Set a variable to make the following commands easier\:

```bash
BACKUP="/media/username/BackupDrive/JetsonBackup"
```

Create the directory\:

```bash
mkdir -p "$BACKUP"
```

Verify it\:

```bash
ls -ld "$BACKUP"
```

If you get a permission error, do not immediately use `sudo` on every command. First check whether the drive is mounted read-write and whether your user has permission to write to it.

### 4.5 Make sure the drive has sufficient free space

Run\:

```bash
df -h "$BACKUP"
```

Check the `Avail` column.

For a file-level backup, the drive needs sufficient space for the files being copied. For a full-device image, plan for an amount of space approximately equal to the device's total capacity, unless the imaging method specifically supports a smaller backup.

---

## 5\. Step 3 - Back up your personal files and robot projects

This is the first actual backup. It does not reformat your Jetson or reinstall Ubuntu.

We will copy your home directory and important project files to the external drive using `rsync`\.

### 5.1 Check whether `rsync` is installed

Run\:

```bash
rsync --version
```

If the command prints version information, continue.

If it says `command not found`, and your Jetson has internet access, you can install it with\:

```bash
sudo apt update
sudo apt install rsync
```

If you are working offline, you may already have it installed; otherwise, we can arrange for the required package to be installed from an offline package repository.

### 5.2 Back up your home directory

First, verify the destination path carefully\:

```bash
echo "$BACKUP"
```

Then run\:

```bash
rsync -aHAX --info=progress2 \
  --exclude='.cache/' \
  "$HOME/" \
  "$BACKUP/home/$USER/"
```

Here is what each part means\:

| Option or expression | Meaning |
|--------|--------|
| `rsync` | Copies files efficiently and can synchronize them again later. |
| `-a` | Archive mode: preserves common file attributes, permissions and timestamps. |
| `-H` | Preserves hard links. |
| `-A` | Preserves access control lists where supported. |
| `-X` | Preserves extended attributes where supported. |
| `--info=progress2` | Shows overall transfer progress. |
| `--exclude='.cache/'` | Skips cache directories to reduce unnecessary backup data. |
| `"$HOME/"` | The source: your home directory and its contents. |
| `"$BACKUP/home/$USER/"` | The destination: your files on the external drive. |

The trailing slash after `"$HOME/"` means “copy the contents of this directory.”

For example, a file at\:

```text
/home/username/Projects/robot/main.py
```

would be copied to a corresponding location under\:

```text
/media/username/BackupDrive/JetsonBackup/home/username/
```

The command may take several minutes or much longer, depending on the amount of data and the speed of the drive.

**Important\:** Do not disconnect the drive while the command is running. Wait for it to finish and check that the command returns to the terminal prompt without reporting errors.

### 5.3 Back up important projects outside your home directory

Suppose your project is located at\:

```text
/opt/robot_project
```

You could back it up with\:

```bash
sudo rsync -aHAX --info=progress2 \
  /opt/robot_project/ \
  "$BACKUP/opt/robot_project/"
```

Only use this example after verifying that the directory actually exists.

To check\:

```bash
ls -ld /opt/robot_project
```

For another project, replace the source path with its actual location.

### 5.4 Find other important development directories

Run\:

```bash
ls -ld /opt /usr/local /srv 2>/dev/null
```

Inspect these locations for your own source code, custom libraries, scripts or models. Do not blindly copy all of `/usr`, `/var` or the entire root filesystem as if it were a normal project directory.

If you have built a Python virtual environment, record where it lives. For example\:

```bash
find "$HOME" -maxdepth 4 -type f -name pyvenv.cfg -print
```

This can help you locate virtual environments under your home directory. Some environments may be deeper than four directory levels, and environments outside your home directory require separate inspection.

A copied Python virtual environment is not guaranteed to work on a restored system if its Python version, system libraries or absolute paths change. Back up the project requirements as well.

---

## 6\. Step 4 - Back up the installed software information

Your files alone do not tell you everything that was installed through Ubuntu's package manager.

We will record package information so you have a reference when rebuilding the system.

### 6.1 Record the installed Ubuntu packages

Run\:

```bash
dpkg --get-selections \
  > "$BACKUP/installed-packages.txt"
```

This creates a text file containing package selections.

For a more detailed package list, run\:

```bash
apt-mark showmanual \
  > "$BACKUP/manually-installed-packages.txt"
```

This records packages marked as manually installed, which can help identify software you intentionally added.

Neither file is a complete backup of the actual installed packages. You may need to download or reinstall the corresponding packages during recovery.

### 6.2 Record the NVIDIA Jetson software version

Run\:

```bash
cat /etc/nv_tegra_release \
  > "$BACKUP/nvidia-jetson-release.txt"
```

Record the Ubuntu release\:

```bash
cat /etc/os-release \
  > "$BACKUP/ubuntu-release.txt"
```

Record the kernel version\:

```bash
uname -a \
  > "$BACKUP/kernel-version.txt"
```

These records will help you identify the software version that was working before a failure.

### 6.3 Save your Python package lists

If you use the default Python installation, run\:

```bash
python3 -m pip freeze \
  > "$BACKUP/python3-packages.txt"
```

If a project uses a virtual environment, activate that environment first, then run the same command\:

```bash
python -m pip freeze \
  > "$BACKUP/project-python-packages.txt"
```

This second command assumes you have already activated the correct environment.

For example, if the environment is at `~/robot_env`, you might activate it with\:

```bash
source "$HOME/robot_env/bin/activate"
```

Then run\:

```bash
python -m pip freeze \
  > "$BACKUP/robot-env-packages.txt"
```

These files record Python package names and versions. They do not contain the packages themselves, so preserve any offline `.whl` files or other package archives you have downloaded separately.

This is particularly important when a Jetson must later be restored without internet access.

---

## 7\. Step 5 - Back up important system configuration files

Now we will preserve some system settings that can be useful when rebuilding your Jetson.

### 7.1 Create a directory for system configuration

Run\:

```bash
mkdir -p "$BACKUP/system-config"
```

### 7.2 Save the network configuration information

Run\:

```bash
ip address show \
  > "$BACKUP/system-config/ip-addresses.txt"
```

Then\:

```bash
ip route show \
  > "$BACKUP/system-config/ip-routes.txt"
```

These files record the current network interfaces and routes. They do not contain every Wi-Fi or network setting.

### 7.3 Back up the APT repository configuration

Ubuntu uses APT to install packages. Repository settings are important when rebuilding your software environment.

Run\:

```bash
sudo tar -czf "$BACKUP/system-config/apt-config.tar.gz" \
  /etc/apt
```

This archives the APT configuration directory.

The archive may contain repository URLs and signing-key configuration. Review its contents before sharing it with anyone.

### 7.4 Back up selected system configuration files

You can archive selected configuration directories\:

```bash
sudo tar -czf "$BACKUP/system-config/selected-config.tar.gz" \
  /etc/hostname \
  /etc/hosts \
  /etc/fstab \
  /etc/ssh
```

These files can help you understand how the old system was configured.

**Security warning\:** The SSH directory may contain private keys or host keys. Keep this backup secure and do not upload it publicly. Also, do not blindly restore old configuration files over a newly installed operating system; some settings may not be appropriate for the new installation.

You do not need to copy all of `/etc` to get started. Some files contain machine-specific settings, secrets or automatically generated configuration that should be handled carefully.

---

## 8\. Step 6 - Verify that the backup is actually usable

A backup is not trustworthy just because the copying command finished.

### 8.1 Check the backup directory

Run\:

```bash
find "$BACKUP" -maxdepth 3 -type f
```

You should see your package lists, release information and any configuration archives you created.

To inspect the copied home directory\:

```bash
ls -lah "$BACKUP/home/$USER"
```

### 8.2 Compare the source and backup directories

Run\:

```bash
du -sh "$HOME"
```

Then\:

```bash
du -sh "$BACKUP/home/$USER"
```

The sizes may differ because of excluded cache files, filesystem allocation, sparse files and other factors. Similar sizes alone do not prove that every file was copied correctly.

### 8.3 Perform a dry-run comparison

A dry run checks what `rsync` would copy or update without actually making those changes.

Run\:

```bash
rsync -aHAXn --delete \
  --exclude='.cache/' \
  --itemize-changes \
  "$HOME/" \
  "$BACKUP/home/$USER/"
```

The `-n` option means dry run.

The `--delete` option is safe in this particular command because it is combined with `-n`, so it will not actually delete files. It shows what would be removed from the destination to make it match the source.

**Never remove `-n` from this comparison command casually.** If you later run it with `--delete` active, files present only in the backup destination can be deleted.

### 8.4 Calculate a SHA-256 checksum for an archive

For example, to verify the integrity of the APT configuration archive, run\:

```bash
sha256sum \
  "$BACKUP/system-config/apt-config.tar.gz" \
  > "$BACKUP/system-config/apt-config.sha256"
```

Then check it\:

```bash
cd "$BACKUP/system-config"
sha256sum -c apt-config.sha256
```

If it prints `OK`, the archive matches the checksum you recorded.

Remember: a checksum verifies that a file has not changed relative to the recorded checksum. It does not prove that the backup contains every file you need.

### 8.5 Safely disconnect the drive

When all commands have finished\:

1. Close any file manager windows using the drive.
2. Use Ubuntu's eject or safely-remove option.
3. Wait for the system to confirm that the drive can be removed.
4. Disconnect the drive.

Keep the drive somewhere safe, preferably separate from the Jetson itself.

---

## 9\. Step 7 - Create a full-system recovery backup

The file-level backup protects your projects and configuration, but it does not provide a complete recovery image of your Jetson.

For a full-system backup, NVIDIA provides a backup-and-restore workflow in its Jetson Linux tools. NVIDIA distinguishes this from cloning: the backup-and-restore workflow can include internal eMMC and QSPI partitions, whereas cloning the `APP` partition captures the root filesystem partition. \[[Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com); [Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com)\]

The correct procedure depends on your JetPack release and storage arrangement.

### 9.1 Prepare a separate Ubuntu host PC

For the NVIDIA SDK Manager workflow, NVIDIA documents an Ubuntu 20.04 or 22.04 x86-64 host PC. You will also need the appropriate Jetson Linux software packages and a compatible USB cable. \[[BSP Setup — Jetson Orin Nano Developer Kit](https://docs.nvidia.com/jetson/orin-nano-devkit/user-guide/setup_bsp.html?utm_source=chatgpt.com); [Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com)\]

Your Windows computer can still be used for storing backup files, but the documented SDK Manager recovery workflow uses an Ubuntu host.

### 9.2 Identify the appropriate Jetson Linux package

On the Jetson, run\:

```bash
cat /etc/nv_tegra_release
```

Keep the result.

Download the matching Jetson Linux release and associated tools from the official [developer.nvidia.com](https://developer.nvidia.com/embedded/jetson-linux?utm_source=chatgpt.com) page.

Do not choose a different release just because it is newer. A backup and recovery procedure should be compatible with the existing board, firmware, storage and software release.

### 9.3 Locate the NVIDIA backup-and-restore tools

In the extracted NVIDIA Linux for Tegra directory, NVIDIA documents this location\:

```text
Linux_for_Tegra/tools/backup-restore/
```

The accompanying instructions are in\:

```text
README_backup_restore.txt
```

Read that file before starting a backup or restore. It specifies the workflows and their prerequisites. \[[Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com)\]

### 9.4 Do not run a guessed backup command

You may encounter commands online resembling\:

```bash
sudo ./tools/backup_restore/l4t_backup_restore.sh ...
```

However, the required options and workflow can differ by release, board configuration and storage arrangement.

For that reason, I do not recommend running a command copied from another Jetson model without checking the matching README.

In particular, the following are different operations\:

- **File backup\:** Copies selected files and folders.
- **Root filesystem clone\:** Captures the operating system's main filesystem partition.
- **Full-device backup\:** Attempts to preserve the relevant partitions required for device recovery.
- **Re-flashing\:** Writes system software to a device and can erase existing data.

A restore or flash operation can destroy the contents of the destination device. Never test one on your only copy of your files.

### 9.5 Understand the microSD versus NVMe issue

The Jetson Orin Nano uses boot firmware and external target storage. Depending on the configuration, that storage may be a microSD card or an NVMe SSD. NVIDIA documents separate flashing and recovery considerations for these storage arrangements. \[[BSP Setup — Jetson Orin Nano Developer Kit](https://docs.nvidia.com/jetson/orin-nano-devkit/user-guide/setup_bsp.html?utm_source=chatgpt.com); [Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com)\]

This means that simply making an image of the NVMe SSD may not preserve every boot component required to recreate the complete original configuration.

If your system boots from an NVMe SSD, the exact recovery workflow needs to account for both the NVMe root filesystem and the relevant boot firmware or boot partitions.

If your system boots from microSD, we need to identify whether you want a copy of that card or a recovery backup using NVIDIA's tools.

---

## 10\. Step 8 - Restore the backup when Ubuntu stops working

There are two different recovery situations.

**Situation A: Ubuntu still boots**

If Ubuntu boots but a project or configuration file is missing, connect the backup drive and copy the needed files back. Avoid replacing the entire home directory unless you really intend to overwrite it.

---

**Situation B: Ubuntu cannot boot**

You may need to boot or connect the Jetson in recovery mode from another computer, then use the compatible NVIDIA flashing or recovery tools. This is more involved than restoring ordinary files.

### 10.1 Restore an individual project

Suppose your project backup is at\:

```text
JetsonBackup/opt/robot_project/
```

After checking the destination, you can restore it with a command such as\:

```bash
sudo rsync -aHAX \
  "$BACKUP/opt/robot_project/" \
  /opt/robot_project/
```

This merges the backed-up files into the destination. It does not remove destination-only files.

Be sure the destination is the correct project directory before running it.

### 10.2 Restore a Python environment

First, reinstall the appropriate Python version and system dependencies. Then recreate a virtual environment and install compatible packages from your saved requirements or offline package files.

For example\:

```bash
python3 -m venv "$HOME/robot_env"
```

Activate it\:

```bash
source "$HOME/robot_env/bin/activate"
```

Then install the appropriate dependencies from your saved package list or offline wheelhouse.

This is an example of rebuilding an environment, not a guarantee that every package in an old package list will install successfully. Packages with compiled extensions may require compatible versions of Python, CUDA, system libraries and architecture-specific wheels.

### 10.3 Restore a full system image

Do not use the project-copy commands above to recover a system that cannot boot.

For a full recovery, follow the `README_backup_restore.txt` instructions for the exact NVIDIA release, or use the documented SDK Manager flashing workflow. Make sure the target board, storage device and release are correct before starting. \[[Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com); [BSP Setup — Jetson Orin Nano Developer Kit](https://docs.nvidia.com/jetson/orin-nano-devkit/user-guide/setup_bsp.html?utm_source=chatgpt.com)\]

---

## 11\. Your backup checklist

Use this checklist as you work through the process.

## Jetson backup progress

of

## 12\. Let's choose the correct full-system method for your Jetson

I can give you the exact commands for the next stage, but I need to establish your hardware and storage configuration first. That will prevent us from accidentally selecting the wrong disk or using a recovery procedure for the wrong Jetson release.

Please run these **three commands on your Jetson** and paste the outputs here\:

```bash
cat /etc/nv_tegra_release
```

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

```bash
df -h /
```

Also, tell me one thing: **Is your Ubuntu 22.04 installed on a microSD card or an NVMe SSD?** If you are unsure, the command output will help us determine it.

Once we know that, we can proceed with the appropriate full-system backup procedure rather than risking your existing installation.

## Prompt:
10/26/2026, 1:47:26 AM

If I choose method B in very very detail step by step

## Response:
10/26/2026, 1:47:30 AM · gpt-6-mini

> **Searched 6 websites**
>
> 
>
> Worked for 11s

# Method B: Create a full storage image of your Jetson Orin Nano running Ubuntu 22.04

We will focus on **Method B: making a full image of the storage device containing your Jetson system**\.

The objective is to create a backup file that you can keep on an external drive and, when necessary, write back to a compatible storage device to recover the system.

This is useful for your robotics development because it can preserve your installed Ubuntu system, development tools, robot SDKs, Python environments, configuration files and project files, provided they are stored on the imaged device.

There is one important limitation: a storage image captures the device or partition you image. It does not automatically include boot firmware or data stored on a separate device.

## 1\. Understand what we are going to do

[![Jual Nvidia Jetson Orin Nano Super Developer Kit - 8gb RAM 67-tops Ai Performance Di Seller Badank Electronic - Fas-bdg - Kota Bandung | Blibli](https://images.openai.com/static-rsc-4/A_aRVdDFEqzMYVQgrIKHkx5ml8GTuX-zNkLrRwxxOva6gxI7al_2UjvyF21BclJFOOuX8b7L6Pxslt6si6G8-0dQ6WvT_SIL_8SZDq2PbjHS-tzrfJ-Ar6_HKVMm6Bp49iGh8zFBbgylJ5cW1K7p7E0MbZN4i74XtrT6YGaVGL_D3v6IeZ-3hl6-T5U3k1kL?purpose=fullsize)](https://www.blibli.com/p/nvidia-jetson-orin-nano-super-developer-kit-8gb-ram-67-tops-ai-performance/ps--BAE-70440-00088)

**Step 1 - Identify your Jetson's system storage**

Determine whether Ubuntu runs from microSD or NVMe, and identify the correct device.

[![WESTERN DIGITAL SanDisk Extreme Portable SSD (V3) - 1TB - USB-C - 2000MB/S(R) / 1800MB/S(W) - SDSSDE70-1T00-G25 - Redcorp.com/en](https://images.openai.com/static-rsc-4/6wHX8vEftXGFSrXr8ngBs41E1xqWPlFt5sMDFoV32-fSy9BTe_Vb5ZYB60m7MMGPvX7hjzKMAxqy1jAXYgDgoO-aS7gv92CYCzdPYyaYCv-nFmliWmdPjj90LSW4YBLq-aUm2ob3eENL_ubC5LcKpNNcg3P069rz-jqawgGaWCN8mcSaqzocR0BO5k3epfka?purpose=fullsize)](https://www.redcorp.com/en/product/ssd-usb-firewire/western-digital/sandisk-extreme-portable-ssd-v3-1tb-usb-c-2000mb-s-r-1800mb-s-w--sdssde70-1t00-g25/60508454)

**Step 2 - Prepare the backup destination**

Connect a separate drive with sufficient free space.

[![dd - how to clone sd card without mbr with ubuntu? - Ask Ubuntu](https://images.openai.com/static-rsc-4/6HbGC9BVjCRRKvXL97P9UC_feaWjvVsbHdyg55p0_GnkMN2VHHKOoGzXc6B0A5r8-yNDxv_bBdBb3T6PYovgzvc0q55S8_-6SqdUr1nG9O7PLIYA0zWmDpOzoSo_9YxtNIiloECD14ARV6gNRSLIW9gLosklEGyOL-5s4IkJ04uheF0tLhtbYydzU_mZ70CS?purpose=fullsize)](https://askubuntu.com/questions/1371660/how-to-clone-sd-card-without-mbr-with-ubuntu)

**Step 3 - Create and verify the image**

Capture the correct storage device, check the image, and save its SHA-256 checksum.

**Step 4 - Prepare and test the recovery process**

Keep the image safe and restore it only to the intended target device.

**The safest approach depends on whether Ubuntu is running from a microSD card or an NVMe SSD.** For a microSD installation, we can generally image the card from another computer. For an NVMe installation, we need to consider whether the SSD can be imaged while the system is running, whether an offline image is preferable, and whether the Jetson's boot components are stored elsewhere.

I will show you the detailed workflow, including commands, explanations and safety checks.

## 2\. Step 1 - Identify the storage device

Do this before creating any image.

On the Jetson, open Terminal with `Ctrl + Alt + T`\.

### 2.1 Check the NVIDIA release

Run\:

```bash
cat /etc/nv_tegra_release
```

Save the output. We will need it if we later need to restore boot components or re-flash the Jetson.

### 2.2 Identify the system disk

Run\:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

For example, you might see\:

```text
NAME         SIZE TYPE FSTYPE MOUNTPOINTS
mmcblk0      64G  disk
├─mmcblk0p1  63G  part ext4   /
nvme0n1     238G  disk
└─nvme0n1p1 238G  part ext4   /mnt/data
```

In this example\:

- `/dev/mmcblk0` is the whole microSD device.
- `/dev/mmcblk0p1` is its first partition, containing `/`, the root filesystem.
- `/dev/nvme0n1` is the whole NVMe device.
- `/dev/nvme0n1p1` is a partition on the NVMe SSD.

For a full-device image, we generally want the whole device, such as `/dev/mmcblk0`, not just `/dev/mmcblk0p1`\.

A whole-device image can preserve the partition table and other data present on that device, not merely the files in the Ubuntu root filesystem.

### 2.3 Check the root filesystem

Run\:

```bash
findmnt /
```

Example\:

```text
TARGET SOURCE         FSTYPE OPTIONS
/      /dev/mmcblk0p1 ext4   rw,relatime
```

This helps identify the partition currently mounted as `/`\.

**Important\:** These examples are illustrative. Do not copy `/dev/mmcblk0` or `/dev/nvme0n1` into a destructive command unless your own output confirms that it is the correct device.

## 3\. Step 2 - Choose the correct imaging procedure

### Which storage does your Jetson use?

Choose the matching option. Both workflows create a raw image, but the physical steps differ.

Ubuntu is installed on a microSD card.

Ubuntu is installed on an NVMe SSD.

I don't know yet.

[Continue with my storage type]

While you identify the storage type, the following is the procedure that applies to either type of removable storage.

The central safety rule is to **image the storage device while it is not being used as the running system disk**\. A raw image taken while Ubuntu is actively writing to its own root filesystem can capture inconsistent data. For this reason, using a separate host computer is the preferred method for a consistent full-device image.

NVIDIA's own instructions for preparing and writing Jetson microSD images also use a host computer and distinguish the whole-card device from individual partitions. \[[Jetson Orin Nano Developer Kit Getting Started Guide](https://developer.nvidia.com/embedded/learn/get-started-jetson-orin-nano-devkit?nvid=nv-int-bnr-371446&sfdcid=undefined&utm_source=chatgpt.com); [Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com)\]

## 4\. Step 3 - Prepare the host computer and backup drive

For the most reliable procedure, use a separate computer running Ubuntu Linux. Your Windows PC can be used as the host if you boot it into a Linux live environment or use a separate Ubuntu computer with direct access to the storage device.

You need\:

- Your Jetson's microSD card or NVMe SSD.
- A suitable card reader or NVMe USB enclosure.
- An external backup drive with sufficient free space.
- A host computer with enough free storage for the image.
- The ability to identify physical storage devices accurately.

### 4.1 Check the host computer

Open Terminal on the host and run\:

```bash
uname -m
```

This prints the host CPU architecture. A conventional x86-64 Ubuntu PC should report\:

```text
x86_64
```

Now check the host's available storage\:

```bash
df -h
```

Make sure the drive receiving the backup has enough free space. A raw image can be approximately as large as the entire source device, even when much of that device is unused.

For example, a 128 GB microSD card can produce an image of approximately 128 GB before compression.

### 4.2 Create the destination directory

Assume your external backup drive is mounted at `/media/host/BackupDrive`\. Replace this example with its real mount point.

```bash
mkdir -p /media/host/BackupDrive/JetsonImages
```

Check that the destination is mounted\:

```bash
df -h /media/host/BackupDrive
```

Do not save the only copy of your image onto the same card or SSD you are imaging.

---

## 5\. Step 4A - Create a full microSD card image

Follow this section if Ubuntu is installed on a microSD card.

### 5.1 Shut down the Jetson

On the Jetson, run\:

```bash
sudo poweroff
```

Wait until it has shut down completely, then disconnect power.

Remove the microSD card and insert it into the host computer's card reader.

### 5.2 Identify the card on the host

Before inserting the card, you can run\:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

Insert the card and run the same command again.

Identify the newly appearing device by comparing the outputs.

For example, the card might appear as `/dev/sdb`, with partitions such as `/dev/sdb1` and `/dev/sdb2`\.

**Do not assume that `/dev/sdb` is always the card.** Device names can change, and the wrong choice can destroy your host computer's data.

### 5.3 Unmount the card's partitions

If Ubuntu automatically mounted the card, unmount its partitions before imaging.

For example, if the device is confirmed to be `/dev/sdb`\:

```bash
lsblk /dev/sdb
```

Inspect the listed partitions and mount points.

Unmount each mounted partition individually. For example\:

```bash
sudo umount /dev/sdb1
```

Only run this example if `/dev/sdb1` is actually a partition of the microSD card and is mounted.

Repeat for any other mounted partitions. Do not unmount partitions belonging to your host operating system.

### 5.4 Create the image

Once the source device is positively identified and its partitions are unmounted, run a command like this\:

```bash
sudo dd if=/dev/sdb \
  of=/media/host/BackupDrive/JetsonImages/jetson-backup.img \
  bs=4M status=progress conv=fsync
```

Replace `/dev/sdb` with your confirmed source device.

Explanation\:

- `sudo` gives the command permission to read the raw device.
- `dd` copies raw bytes from one location to another.
- `if=` identifies the input device.
- `of=` identifies the output image file.
- `bs=4M` copies data in 4 MiB blocks.
- `status=progress` displays progress.
- `conv=fsync` requests that output data be synchronized before completion.

This command reads the card and writes an image file. It does not write to the card because the card is specified as the input.

Wait for the command to finish. Do not unplug the card or backup drive during the operation.

### 5.5 Verify the image file

Check its size\:

```bash
ls -lh /media/host/BackupDrive/JetsonImages/jetson-backup.img
```

Record its checksum\:

```bash
cd /media/host/BackupDrive/JetsonImages
sha256sum jetson-backup.img > jetson-backup.img.sha256
```

Verify it\:

```bash
sha256sum -c jetson-backup.img.sha256
```

You should see\:

```text
jetson-backup.img: OK
```

This verifies the image against the checksum recorded immediately after imaging. For stronger protection, keep a second copy of the checksum separately.

### 5.6 Check the image's partition table

If the host has the `fdisk` utility, run\:

```bash
sudo fdisk -l /media/host/BackupDrive/JetsonImages/jetson-backup.img
```

The image should show a partition table consistent with the source card.

This check is useful, but it does not prove that every partition can be restored or that the Jetson will boot successfully.

---

## 6\. Step 4B - Create a full NVMe SSD image

Follow this section if Ubuntu is installed on an NVMe SSD.

The preferred raw-imaging method is to shut down the Jetson, remove the SSD, and connect it to the host computer through a compatible NVMe USB enclosure.

If you are not comfortable removing the SSD, do not force it. We can instead investigate the NVIDIA backup-and-restore procedure for your exact Jetson Linux release.

### 6.1 Shut down and remove the SSD

1. Run `sudo poweroff` on the Jetson.
2. Disconnect the power supply.
3. Follow appropriate electrostatic-discharge precautions.
4. Remove the NVMe SSD according to the hardware instructions for your carrier board.
5. Place the SSD in a compatible NVMe enclosure.
6. Connect the enclosure to the host computer.

Do not remove or insert the SSD while the Jetson is powered on.

### 6.2 Identify the SSD

On the host, run\:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

Find the newly connected SSD.

It might appear as `/dev/sdc` on one computer, but another computer could assign it a different name.

Verify its model and capacity. Make certain you are not selecting the host computer's internal SSD.

### 6.3 Unmount the SSD's partitions

If the host automatically mounted any partitions from the SSD, unmount those partitions.

For example, if the SSD is confirmed to be `/dev/sdc`\:

```bash
lsblk /dev/sdc
```

Inspect the output and unmount only the partitions belonging to that SSD.

### 6.4 Create the NVMe image

After verifying the source and destination, use\:

```bash
sudo dd if=/dev/sdc \
  of=/media/host/BackupDrive/JetsonImages/jetson-nvme-backup.img \
  bs=4M status=progress conv=fsync
```

Replace `/dev/sdc` with the correct device.

This copies the entire SSD, including its partition table and data in its partitions. It may take a considerable amount of time for a large SSD.

### 6.5 Verify the NVMe image

Run\:

```bash
cd /media/host/BackupDrive/JetsonImages
sha256sum jetson-nvme-backup.img > jetson-nvme-backup.img.sha256
sha256sum -c jetson-nvme-backup.img.sha256
```

Then inspect the partition table\:

```bash
sudo fdisk -l jetson-nvme-backup.img
```

Keep the image and checksum together.

**Important limitation\:** an NVMe image does not necessarily include boot firmware stored in the Jetson's separate QSPI flash. You may need a compatible NVIDIA recovery procedure to restore the firmware and boot configuration as well. NVIDIA's documentation describes separate procedures for NVMe storage and Jetson boot components. \[[Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com); [Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=clone&utm_source=chatgpt.com)\]

---

## 7\. Step 5 - Restore the image if necessary

Restoring a raw image is destructive to the destination device. It overwrites its existing contents.

Only restore after confirming the target device, checking the image, and ensuring you have copies of any data that must be retained.

### 7.1 Restore a microSD card image

Connect the replacement card to the host computer.

Identify the device again\:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

Make sure the replacement card is at least as large as the original image requires. Two cards advertised with the same capacity may have slightly different actual byte capacities.

Unmount any mounted partitions of the replacement card.

Then, **only after confirming the destination device**, run a command such as\:

```bash
sudo dd if=/media/host/BackupDrive/JetsonImages/jetson-backup.img \
  of=/dev/sdX \
  bs=4M status=progress conv=fsync
```

Replace `/dev/sdX` with the confirmed whole replacement card device. Do not use a partition such as `/dev/sdX1`\.

This command overwrites the destination card. An incorrect destination can destroy the host computer's data.

Wait for it to finish, safely eject the card, insert it into the powered-off Jetson, and start the Jetson.

A successful write does not guarantee that the board will boot. If it does not boot, the original system may have depended on other boot components, or the replacement card may have a different capacity or a hardware issue.

### 7.2 Restore an NVMe SSD image

Connect the replacement NVMe SSD to the host through the enclosure, identify it, and unmount its partitions.

Check that its actual capacity is sufficient for the image.

Then, after confirming the destination, the equivalent write operation is\:

```bash
sudo dd if=/media/host/BackupDrive/JetsonImages/jetson-nvme-backup.img \
  of=/dev/nvmeXn1 \
  bs=4M status=progress conv=fsync
```

Here, `/dev/nvmeXn1` is only a placeholder. Replace it with the actual whole SSD device name identified on the host. A USB enclosure may expose the SSD under a different name, such as `/dev/sdX`\.

Do not run the command until you have positively identified the destination.

After writing the image, reinstall the SSD in the Jetson and test the boot process. If boot firmware or QSPI components need restoration, use the appropriate NVIDIA recovery procedure for your release. \[[Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com); [Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=clone&utm_source=chatgpt.com)\]

---

## 8\. Step 6 - Maintain a safe backup strategy

I recommend keeping\:

- One raw storage image on an external drive.
- A second copy of the image on a separate drive or other secure storage.
- The SHA-256 checksum for each image.
- The Jetson Linux release information.
- A separate file-level backup of your projects and important configurations.
- Notes describing the exact storage device and restore procedure.

Test your recovery procedure on a spare compatible storage device if possible. Never use your only backup as the test target.

## 9\. What I need from you to make the commands exact

The commands above show the general method, but the source and target device names must be confirmed on your actual hardware.

Please tell me whether your Jetson Orin Nano boots from\:

- **A.** A microSD card
- **B.** An NVMe SSD
- **C.** I'm not sure

Also, is your separate computer running Windows or Ubuntu Linux?

With those two details, I can give you the exact step-by-step procedure for your setup, including which device to select, how to store the image, and how to restore it safely.

## Prompt:
10/26/2026, 1:48:43 AM

If I choose A, you explain step by step in very detail

## Response:
10/26/2026, 1:48:47 AM · gpt-6-mini

> **Planning the backup**
>
> I’m preparing a careful, cross-platform procedure for creating a complete microSD image before modifying anything. I’ll emphasize identifying the correct device, unmounting it, verifying the image, and restoring it safely later.
>
> **Planned the backup**
>
> 
>
> **Searched 7 websites**
>
> 
>
> Worked for 22s

# Method B - Option A: Back up the Jetson Orin Nano's microSD card

We will assume you chose **A: Ubuntu 22.04 is installed on a microSD card** in your Jetson Orin Nano.

Our goal is to make a complete raw image of that microSD card on a separate computer. If your system later becomes corrupted, you can write the image to a compatible replacement card and attempt to restore your original system.

This method is especially useful when you have already installed robot SDKs, Python packages, compilers, libraries and development projects that would take a long time to set up again.

## What you will accomplish

[![NVIDIA Jetson Orin Nano: Der ultimative Leitfaden für Steckverbinder und Funktionen](https://images.openai.com/static-rsc-4/kfwnLukogTjabitG43TRk_XCDL0z-YAkHbgwO4yD8XHb73Ml-4wH_pphkJNABqVYZ9mES8Ql9-sTc7IrLqPkB8YHzVQ6-GY5uBw2iFcTIB_TSWdQFPYUarI7rawvPMbyeicv--8g7ZLM7wcYL39ZFfKDqIRBERauuXuMK8x0vjsXdXpPPDcJABvSo0hCydNI?purpose=fullsize)](https://de.linkedin.com/pulse/nvidia-jetson-orin-nano-ultimate-guide-connectors-ummadisetti-oeovc?tl=de)

**1\. Prepare the Jetson**

Confirm Ubuntu, identify the microSD card and shut down safely.

---

[![【楽天市場】超小型microSDカードリーダー USB Aコネクタ：サンワダイレクト楽天市場店](https://images.openai.com/static-rsc-4/kylEqNev5xHkfC_j-f73b7i3d3nQ7D8V0tK9wrbqAq7mTAPJI9znUsdzCNqh_NaDlfAh7Zv5Fozwf3yq6gYYmNZG_PKtiVEzLLvfZWKBEMiiPq3CkhURkg4ej0Ai5ZQoveO2yvwK_c_1gt-nXhygACRDbkE-Fd5lnPgW79Qd5Uy5WbBkq5UZnKJF83AD94-G?purpose=fullsize)](https://item.rakuten.co.jp/sanwadirect/adr-3msd1/)

**2\. Prepare the host computer**

Use a card reader and an external drive with sufficient free space.

---

[![How to create disk images using GNOME Disk - TechRepublic](https://images.openai.com/static-rsc-4/AQtM6uk90OvV1nmL1fyf4N0lUZ87WnQDA-Y-3r9H2WcqMMzT8jeLwGOIkoxgYwJoo6L079p6BdvvIPBg6KHxrL1kEO5MfVRoj8ktr-c8IBYKCHaIhCwARZWod-xRNdwGfmBwSIl68kYYVn1cBVj-K814JRFVmL7DQK59XGjZhv_JKFTQEGGUoJRKhF42uTeJ?purpose=fullsize)](https://www.techrepublic.com/article/how-to-create-disk-images-using-gnome-disk/)

**3\. Create and verify the image**

Capture the whole card, check the image, and record its SHA-256 checksum.

---

[![Ssd Drive Pictures | Download Free Images on Unsplash](https://images.openai.com/static-rsc-4/nrEfcf7VEYkPWpEJwqw-BZE0yMBlCqlBRDwAz1I2b5N6Q9AO0txlKUALNlNDaio136pAye-ONz_Rctf5gKPwwBiBJ6QiSK9y80mNZqDkGjdO8R64DgCIesPMrNwGybOyQtTbiqFxL8OmO25rqxe63gBHXnmqfVF8nnDeNW0JZG1DkWioP63PrA5DnwhnKlM8?purpose=fullsize)](https://unsplash.com/s/photos/ssd-drive)

**4\. Restore when needed**

Write the image to a suitable replacement card and test the Jetson.

## 1\. Understand what a full microSD image contains

Imagine your microSD card is a book containing many sections\:

- A partition table describing how the card is divided.
- Ubuntu system files.
- NVIDIA Jetson Linux files stored on the card.
- Installed software and libraries.
- Your personal files and robot projects.
- Other partitions or data stored on that card.

A raw image copies the card's bytes into a single file, for example\:

```text
jetson-orin-nano-backup.img
```

Unlike a simple copy of your home directory, this image can preserve the card's partition layout and the data in its partitions.

However, the image captures **only the microSD card**\. Boot firmware stored in the Jetson's separate QSPI flash, or data stored on another drive, is not included. If the board's boot firmware needs recovery too, you may need NVIDIA's compatible recovery or flashing tools.

## 2\. Step 1 - Prepare the equipment

Before touching the microSD card, collect the following items.

[![Quick Start Guide — Jetson Orin Nano Developer Kit - User Guide](https://images.openai.com/static-rsc-4/1Pich7u2bIafQMOhEm3h8uOGAS1myj4QCTR19uDUGtI4joHK8RY4rqVKYGjM8KbNEKM-Y8KaJFfbxI-xzfnk836HhhcmO_wftVAOUAz6-U6WT85aihIXGT8KbsdQglK-DnU6aKemAcUHVfQE7sMbM5E8Tuz1D0dtpdTSPWWqCzgSw62IKpkPWdKNRJUr6j1p?purpose=fullsize)](https://docs.nvidia.com/jetson/orin-nano-devkit/user-guide/quick_start.html)

**A. Jetson Orin Nano**

Your existing system with Ubuntu 22.04 installed on the microSD card.

---

[![【最新版】ドラレコにおすすめのSDカード5選(2026）｜失敗しない高耐久タイプ＆容量の選び方｜カメラマン養成講座【迷わず選べるカメラと機材のセレクトガイド】](https://images.openai.com/static-rsc-4/MBlGLHRvCMXdDRwdYWpVxVWQ4Wsl6VaysffSoXU-QLWXscZCywZAuDbx0Tj_gdgFqTcS9qVVEcVSRu5W5zey8qRmOuiyKAa-rQfGS6cU2luWZoygDqXkdNPhhUuzhoKwAXwwRlsunlzQyC2M-GnmhvA-F6yggQQFPqU6UBuM8ATCDWwA4GiF6HeLq7AxaT_j?purpose=fullsize)](https://note.com/cos_cameraman1/n/n7b43274444b4)

**B. The original microSD card**

This is the card we will image. Do not format it.

---

[![ADR-3TCMS10 �����^ microSD�J�\[�h���\[�_�\[ USB Type-C�R�l�N�^�b�T���v�������ݏo�Ή�  |�T�����_�C���N�g](https://images.openai.com/static-rsc-4/0lF4WUCY5yFp5dj7tJSq6UtcTt_fFjsV060FWGC1ZD57NQ5s7HoP6nlptTM8nIO00N3MSNPefCDnG4BaouEZ6jFZIBL53N8yNt6SBzInHByN2Eum4Pt16rqlhQjjTSleiaE2L417na5FflPakyMRniMOgINoCfkhNwLHr1fehyRt2R_APkqh4_4bBxP656Bm?purpose=fullsize)](https://direct.sanwa.co.jp/ItemPage/ADR-3TCMS10)

**C. A card reader**

It allows the host computer to read the card as a physical storage device.

---

[![Kinpower Stockage Mobile 500Go - Disque Dur SSD 2.5' Externe | DIY Micro](https://images.openai.com/static-rsc-4/KqAi6HT0pJdHyhtE5PvhA3olQc_hUwosKu7yiZ4veaB1cJJAbYFWAU29wqOnjSPm9QKIE2WHTBUoOU8R9Yk90BH7D0uox8RzQWZlVhMRkOlyA9uw5WcYUb6SXsJbSndNBEbtWEGBGJJblf7lBEi1BIPwCw9C1z8-1CFzA6GqVlzOakDgK5ENSIy1NeDPFCG2?purpose=fullsize)](https://www.diymicro.fr/products/kinpower-stockage-mobile-500go-disque-dur-ssd-2-5-externe)

**D. An external backup drive**

It stores the image independently of the original microSD card.

### How much space do you need?

For example, if your microSD card is 128 GB, reserve approximately 128 GB for an uncompressed raw image, plus additional space for other backups.

The image can be compressed later, but its compressed size depends on the contents of the card.

A useful rule is\:

$$
\text{Free space required} \geq \text{Capacity of the original card}
$$

This is a conservative estimate for an uncompressed image.

## 3\. Step 2 - Inspect the Jetson before shutdown

Start your Jetson normally and open Terminal.

### 3.1 Confirm the Ubuntu version

```bash
cat /etc/os-release
```

Look for `VERSION_ID="22.04"`\.

### 3.2 Record the NVIDIA software release

```bash
cat /etc/nv_tegra_release
```

Save the output somewhere on your host computer. It may be useful if you need to rebuild the system later.

### 3.3 Check the root partition

```bash
findmnt /
```

You may see something similar to\:

```text
TARGET SOURCE         FSTYPE OPTIONS
/      /dev/mmcblk0p1 ext4   rw,relatime
```

Here, `/dev/mmcblk0p1` is the partition mounted as the Ubuntu root filesystem. The whole card is likely `/dev/mmcblk0`, but confirm this in the next step.

### 3.4 Examine the storage layout

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

Write down\:

- The name of the whole microSD device.
- Its capacity.
- The partition mounted at `/`\.
- Any other storage devices attached to the Jetson.

For a typical microSD-based installation, the whole card may be `/dev/mmcblk0`\. Your device may differ, so treat this as an example only.

### 3.5 Shut down the Jetson safely

Run\:

```bash
sudo poweroff
```

Wait until the Jetson has completely shut down. Disconnect its power before removing the card.

Do not pull out the microSD card while Ubuntu is running. Doing so could corrupt the filesystem or damage the card's contents.

## 4\. Step 3 - Connect the microSD card to the host computer

We will use a separate host computer so that the card is not being used as the running Ubuntu system disk while the image is created.

### 4.1 Remove and insert the card

1. Confirm that the Jetson has powered off.
2. Remove the microSD card carefully.
3. Insert it into the card reader.
4. Connect the card reader to the host computer.
5. Wait for the computer to detect the card.

If Windows says that the drive must be formatted before it can be used, **cancel that prompt**\. Windows may not recognize the Linux filesystems on the card. Formatting it would erase data.

### 4.2 If your host computer runs Ubuntu Linux

Open a terminal on the host computer.

First, list the storage devices before inserting the card\:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

Then insert the card and run the command again\:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

Compare the two outputs. The newly appearing device is likely your microSD card.

For example\:

```text
NAME         SIZE TYPE FSTYPE MOUNTPOINTS MODEL
sda          477G disk                    External SSD
├─sda1       477G part ext4   /media/host/Backup
sdb          119G disk                    USB Card Reader
├─sdb1       118G part ext4
└─sdb2         1G part vfat
```

In this example\:

- `/dev/sdb` is the whole microSD card.
- `/dev/sdb1` and `/dev/sdb2` are partitions on that card.
- `/dev/sda` is a separate external SSD used for backups.

**Never rely on these example names.** Your computer could assign the card `/dev/sdc` or another device name.

Confirm the device's size and model. If you cannot distinguish it confidently from your host's internal drive, stop and inspect the devices before continuing.

### 4.3 Confirm the external backup drive

Run\:

```bash
df -hT
```

Identify the mount point for your external backup drive.

For example\:

```text
Filesystem     Type  Size  Used Avail Mounted on
/dev/sda1      ext4  477G   10G  443G /media/host/Backup
```

Your actual mount point will differ.

Create a directory for the image, substituting your real mount point\:

```bash
mkdir -p /media/host/Backup/JetsonImages
```

Verify that the directory exists and that it is on the intended external drive\:

```bash
df -h /media/host/Backup/JetsonImages
```

Do not proceed if the destination is accidentally on the host computer's system disk or on the microSD card itself.

## 5\. Step 4 - Unmount the microSD partitions

The card must not be actively mounted while you create the raw image.

Suppose you have confirmed that the whole card is `/dev/sdb`\. Inspect its partitions\:

```bash
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINTS /dev/sdb
```

If Ubuntu automatically mounted a partition, unmount it.

For example, if `/dev/sdb1` is mounted\:

```bash
sudo umount /dev/sdb1
```

If `/dev/sdb2` is also mounted\:

```bash
sudo umount /dev/sdb2
```

Only unmount partitions that belong to the confirmed microSD device. Repeat for any other mounted partitions belonging to that card.

Now inspect it again\:

```bash
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINTS /dev/sdb
```

The card's partitions should no longer show mount points.

If `umount` reports that a device is busy, close any file manager windows or terminal sessions accessing the card. Do not force-unmount it without understanding what is using it.

## 6\. Step 5 - Create the full microSD image

We will now create the backup file.

### 6.1 Understand the command before running it

The command uses `dd`, a Linux utility that copies data at the byte level.

Its general structure is\:

```bash
sudo dd if=SOURCE_DEVICE of=DESTINATION_IMAGE bs=4M status=progress conv=fsync
```

The two most important arguments are\:

- `if=` means input file or device. Here, it is the microSD card.
- `of=` means output file. Here, it is the backup image stored on your external drive.

The direction matters enormously: **the microSD card is the input; the image file is the output.**

### 6.2 Run the command

For this example, assume\:

- The verified microSD card is `/dev/sdb`\.
- The external backup drive is mounted at `/media/host/Backup`\.

Run\:

```bash
sudo dd if=/dev/sdb \
  of=/media/host/Backup/JetsonImages/jetson-orin-nano-ubuntu22.img \
  bs=4M status=progress conv=fsync
```

Replace both example paths with your confirmed paths.

Enter your host computer's password if requested.

The terminal should display progress as the card is copied. Depending on the card capacity, card reader and USB connection, this may take several minutes or considerably longer.

**Do not disconnect either device while the command is running.**

### 6.3 Understand each part of the command

| Command component | Explanation |
|--------|--------|
| `sudo` | Runs the operation with the permissions needed to read the raw device. |
| `dd` | Copies bytes from the input to the output. |
| `if=/dev/sdb` | Reads the whole card in this example, including its partition table. |
| `of=...img` | Writes the data to a regular image file on the backup drive. |
| `bs=4M` | Uses 4 MiB blocks for the copy operation. |
| `status=progress` | Displays progress information. |
| `conv=fsync` | Synchronizes output data before the command completes. |

When the command finishes, you should return to the terminal prompt. If it reports an input/output error, do not assume that the image is complete and valid.

### 6.4 Check the image file

Run\:

```bash
ls -lh /media/host/Backup/JetsonImages/jetson-orin-nano-ubuntu22.img
```

The size should be consistent with the capacity of the original card. Because this is a raw image, it may be close to the entire advertised card capacity, rather than just the amount of space used by Ubuntu.

For example, a 64 GB card may produce an image around 64 GB in decimal capacity.

### 6.5 Inspect the image's partition table

Run\:

```bash
sudo fdisk -l /media/host/Backup/JetsonImages/jetson-orin-nano-ubuntu22.img
```

This should display the partition layout recorded in the image.

You may see several partitions, depending on how the card was prepared.

This inspection can detect some problems, but it does not establish that the operating system will boot successfully after restoration.

## 7\. Step 6 - Verify the backup using SHA-256

Now we will calculate a checksum for the image.

SHA-256 produces a fixed-length fingerprint of a file. If even one bit of the image changes, its checksum will almost certainly change too.

### 7.1 Calculate and save the checksum

On the Ubuntu host, run\:

```bash
cd /media/host/Backup/JetsonImages
```

Then\:

```bash
sha256sum jetson-orin-nano-ubuntu22.img \
  > jetson-orin-nano-ubuntu22.img.sha256
```

This saves the image's SHA-256 checksum in a separate text file.

### 7.2 Check the checksum

Run\:

```bash
sha256sum -c jetson-orin-nano-ubuntu22.img.sha256
```

Expected result\:

```text
jetson-orin-nano-ubuntu22.img: OK
```

This means that the image matches the checksum recorded in the previous step.

**Important\:** This test checks the image against its recorded checksum. It does not prove that the original card was read without errors or that the image contains everything required to boot the Jetson.

For stronger verification, you can read the original card a second time and compare its contents against the image. This takes additional time and requires the original card to remain available.

### 7.3 Keep the checksum with the image

Your backup folder should contain at least\:

```text
JetsonImages/
├── jetson-orin-nano-ubuntu22.img
└── jetson-orin-nano-ubuntu22.img.sha256
```

Store another copy of the checksum separately if possible.

## 8\. Step 7 - If your host computer runs Windows instead

You do not have to install Ubuntu on your Windows PC just to create a microSD image. You can use a disk-imaging utility that supports reading a physical device into an image file.

One option is [sourceforge.net](https://sourceforge.net/projects/win32diskimager/?utm_source=chatgpt.com)\. NVIDIA also documents using a host computer to write Jetson microSD images from Windows. \[[Jetson Orin Nano Developer Kit Getting Started Guide](https://developer.nvidia.com/embedded/learn/get-started-jetson-orin-nano-devkit?nvid=nv-int-bnr-371446&sfdcid=undefined&utm_source=chatgpt.com); [Jetson Orin Nano Developer Kit User Guide - Software Setup](https://developer.nvidia.com/embedded/learn/jetson-orin-nano-devkit-user-guide/software_setup.html?utm_source=chatgpt.com)\]

The important distinction is that writing a downloaded Jetson image to a card is not the same operation as reading your existing card into a backup image.

### 8.1 Install and open the imaging utility

1. Download Win32 Disk Imager from its official project page.
2. Install it on your Windows computer.
3. Connect the microSD card through your card reader.
4. Cancel any Windows prompt asking you to format the card.
5. Run the imaging utility with the permissions it requests.

### 8.2 Select the correct card and image filename

The application typically provides an image-file field and a device selector.

1. Choose an output filename, such as `jetson-orin-nano-ubuntu22.img`\.
2. Select the drive letter associated with the microSD card.
3. Confirm the card's capacity and identity using Windows Disk Management if necessary.
4. Make absolutely sure you selected the microSD card, not another disk.

Do not select the **Write** operation. That operation writes an image onto the selected device and can erase its contents.

### 8.3 Read the card into an image

Select the utility's **Read** operation, which copies the selected physical device into an image file.

Wait for the process to finish. Do not disconnect the card or external backup drive.

If the utility cannot read the full card, or reports an error, do not treat the image as a valid backup.

### 8.4 Verify the checksum in Windows

Open PowerShell and navigate to the folder containing your image.

Run\:

```powershell
Get-FileHash .\jetson-orin-nano-ubuntu22.img -Algorithm SHA256
```

Record the displayed hash in a text file alongside the image.

To verify the file later, run the same command again and compare the hash values.

The SHA-256 checksum should be identical as long as the image file has not changed.

---

## 9\. Step 8 - Safely disconnect the card and backup drive

After the imaging operation and verification finish\:

1. Close the imaging application or finish using the Linux terminal.
2. Safely eject the microSD card from the host computer.
3. Disconnect the card reader.
4. Safely eject the external backup drive.
5. Store the original microSD card and backup drive separately.

Keep the original card unchanged until you have confirmed that the image is safely stored.

Do not use the original card as the first test target when you later try restoring the image. Use a compatible spare card if possible.

## 10\. Step 9 - Restore your Jetson from the image

This section explains how you would use the image if your Ubuntu system later became corrupted.

**Warning\:** Restoration overwrites the destination microSD card. Check the destination device carefully before proceeding.

### 10.1 Prepare a replacement microSD card

Choose a replacement card that is at least as large in actual byte capacity as the original image requires. A card with the same advertised capacity is not always large enough.

Insert the replacement card into the host computer.

### 10.2 Restore on Ubuntu Linux

Identify the replacement card again\:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

Confirm its identity and unmount all mounted partitions belonging to it.

For example, if you have positively identified the replacement card as `/dev/sdb`, the write command would be\:

```bash
sudo dd \
  if=/media/host/Backup/JetsonImages/jetson-orin-nano-ubuntu22.img \
  of=/dev/sdb \
  bs=4M status=progress conv=fsync
```

Replace `/dev/sdb` with the actual whole-card device. Do not use a partition name such as `/dev/sdb1`\.

This operation overwrites the replacement card. It must not be run against your host computer's system drive or the wrong storage device.

Wait for the command to finish, then safely eject the card.

### 10.3 Restore on Windows

If you used Win32 Disk Imager to create the backup\:

1. Connect the replacement card.
2. Open the imaging utility.
3. Select your saved `.img` file.
4. Select the replacement microSD card.
5. Double-check that the destination is correct.
6. Choose **Write**, not Read.
7. Wait for the process to finish.
8. Safely eject the card.

This writes your saved image to the replacement card. The utility may not be able to show the Linux partitions in Windows File Explorer afterward; that is normal.

### 10.4 Test the restored card

1. Shut down and disconnect the Jetson's power.
2. Insert the restored microSD card.
3. Reconnect power and start the Jetson.
4. Check whether Ubuntu starts normally.
5. Verify that your development projects and important applications are present.
6. Check the NVIDIA software release and the operation of your robot-related software.

If the Jetson fails to boot, do not immediately conclude that the image is unusable. Boot firmware compatibility, card capacity, card quality and the original system's boot configuration can all matter.

Remember that the raw microSD image does not include separate QSPI boot firmware. A firmware recovery or update using the appropriate NVIDIA tools may be necessary in some situations.

## 11\. Final checklist

## Backup completion

/

## 12\. One last question so I can guide you precisely

What operating system is installed on the **separate computer that you will use to create the backup**?

Host computer operating system

Windows 10 or Windows 11

Ubuntu Linux

Another operating system

---

MicroSD card capacity

64 GB

128 GB

256 GB

Another capacity / not sure

[Give me my exact backup procedure]

I will then tailor the procedure to your computer, so you can follow it one command or one action at a time without risking your existing Ubuntu installation.

## Prompt:
10/26/2026, 1:49:48 AM

An then how to restore it step by step in very details

## Response:
10/26/2026, 1:49:52 AM · gpt-6-mini

> **Searched 9 websites**
>
> 
>
> Worked for 20s

# How to restore your Jetson Orin Nano from a microSD backup - step by step

We will restore the raw microSD image you created for your Jetson Orin Nano running Ubuntu 22.04.

The purpose is to recover your original system, including the installed software, robot SDKs, Python environments, configuration files and development projects that were stored on the original microSD card.

**The most important rule\:** restoring an image overwrites the destination microSD card. We will first verify the backup, identify the replacement card, and only then write the image.

## 1\. Understand the restoration process

[![Integral USB 3.0 Micro SD Card reader - MicroSD, MicroSDHC, MicroSDXC  | Cables 4 ALL](https://images.openai.com/static-rsc-4/fT7frHE4Iny9fExxPAkpP6SJKKQTnCB8zq_aTtKzJSe0HIRqCmy_aCxEzmHWDwdP1U2fjGI7iUcH7WTWDg06XM1IvqSSL53ZjCkX5aD79zC-1d5vsYNR1eDzc-4QxmCPTftqZTXp-PifbCeEsattmpTnqCdXX18TrycemJxoTMDiYF3Xd3jzqC_70m9ymCS8?purpose=fullsize)](https://www.cables4all.co.uk/integral-usb-30-micro-sd-card-reader-4423-p.asp)

**Step 1 - Prepare**

Locate your saved `.img` file and checksum, plus a replacement microSD card.

---

[![ナカバヤシ 変換アダプタ機能付 USB2.0 Type-C接続SDカードカードリーダー ［USB2.0 /スマホ・タブレット対応］ CRWCSD90BK の通販 - カテゴリ：カメラ・ビデオカメラ - ナカバヤシ  家電通販のコジマネット - 全品代引き手数料無料](https://images.openai.com/static-rsc-4/CNumowwGK8j1WOuKgJG4iVU_qTZFknO8XRo0t1O0UuvxbO-rCR0-6ejAVr0YeE7x22hOA55VsyNyxxwx0yEfz6zNR8L2jLnycXGlyE0yz4p_ksND0d9ICFqmr5frsXgqLLzfQe5CORSMniXAOd7BsEAir49zg4c_cacHk6-Dxp8sPtBpVPeXZohBLb16ZaKg?purpose=fullsize)](https://www.kojima.net/ec/prod_detail.html?prod=4902205264040&sku=4902205264040)

**Step 2 - Verify**

Check that the backup file exists and matches its SHA-256 checksum.

---

[![Writing a Raspberry Pi Image Using the Ubuntu DiskUtil](https://images.openai.com/static-rsc-4/pEpiPwfSvmDR6TqZtMW6DvNGSECxo-Es_p4Qju8sdCu9WzO-7zesCaIrot-8OjSuV-wiHVS3jNAbKgbBE36awotUlF8FOT9XwH4WQudD9xdkMx4WRHsvd26O55Ku4W_nLiKd0L3OjjE71K_7gk16gvlQCuPSCFNC7tljeiFfp_QAQ-sBv142IMPD94SpPWNJ?purpose=fullsize)](https://www.louissimons.com/writing-a-raspberry-pi-image-using-the-ubuntu-diskutil/)

**Step 3 - Restore**

Write the image to the correct replacement card using your host computer.

---

[![Quick Start Guide — Jetson Orin Nano Developer Kit - User Guide](https://images.openai.com/static-rsc-4/1Pich7u2bIafQMOhEm3h8uOGAS1myj4QCTR19uDUGtI4joHK8RY4rqVKYGjM8KbNEKM-Y8KaJFfbxI-xzfnk836HhhcmO_wftVAOUAz6-U6WT85aihIXGT8KbsdQglK-DnU6aKemAcUHVfQE7sMbM5E8Tuz1D0dtpdTSPWWqCzgSw62IKpkPWdKNRJUr6j1p?purpose=fullsize)](https://docs.nvidia.com/jetson/orin-nano-devkit/user-guide/quick_start.html)

**Step 4 - Test**

Put the card into the Jetson, start Ubuntu and verify the system.

Before we start, remember that a raw microSD image restores the data captured from the card. It does not automatically restore boot firmware stored separately in the Jetson's QSPI flash, nor any data stored on another drive.

## 2\. Step 1 - Prepare everything before restoring

You will need\:

- Your saved image, such as `jetson-orin-nano-ubuntu22.img`\.
- Its `.sha256` checksum file, if you created one.
- The original or a replacement microSD card.
- A card reader.
- The computer on which the image is stored.
- Enough time for the image to be written and verified.

### 2.1 Decide which card to restore

There are two situations\:

**Case A: You are restoring the original card.** The card will be erased and rewritten. Make sure you do not need any newer files on it.

**Case B: You are restoring a replacement card.** This is preferable for testing, because you can leave the original card untouched.

The replacement card should have at least as much *actual capacity in bytes* as the image requires. Two cards both sold as 128 GB may not have exactly the same usable capacity.

### 2.2 Find your image file

Locate the image on your backup drive.

For example, it might be at\:

```text
E:\JetsonImages\jetson-orin-nano-ubuntu22.img
```

on Windows, or\:

```text
/media/host/Backup/JetsonImages/jetson-orin-nano-ubuntu22.img
```

on Ubuntu Linux.

These are examples. Use the actual location where you saved your image.

Do not extract the image if it is already a `.img` file. If you deliberately compressed it into a `.gz`, `.xz` or `.7z` archive, you must decompress it first or use a compatible imaging tool that supports the format.

### 2.3 Check the image checksum before writing

If you saved a SHA-256 checksum, compare it with the image now. This is important because you do not want to restore a corrupted or incomplete image.

On Windows PowerShell\:

```powershell
Get-FileHash "E:\JetsonImages\jetson-orin-nano-ubuntu22.img" -Algorithm SHA256
```

Compare the displayed hash with the hash you saved previously.

On Ubuntu Linux\:

```bash
cd /media/host/Backup/JetsonImages
sha256sum -c jetson-orin-nano-ubuntu22.img.sha256
```

The expected result is\:

```text
jetson-orin-nano-ubuntu22.img: OK
```

If the checksum does not match, **stop here**\. Do not restore that image until you have investigated the discrepancy or recovered a known-good copy.

A matching checksum confirms that the image matches its recorded fingerprint; it does not independently prove that the original imaging operation captured a bootable system.

---

## 3\. Step 2 - Choose the restoration procedure for your computer

NVIDIA's Jetson Orin Nano documentation supports preparing microSD cards on Windows, macOS and Linux, and documents writing images with compatible imaging tools. \[[Jetson Orin Nano Developer Kit User Guide - Software Setup](https://developer.nvidia.com/embedded/learn/jetson-orin-nano-devkit-user-guide/software_setup.html?utm_source=chatgpt.com); [Jetson Orin Nano Developer Kit Getting Started Guide](https://developer.nvidia.com/embedded/learn/get-started-jetson-orin-nano-devkit?nvid=nv-int-bnr-371446&sfdcid=undefined&utm_source=chatgpt.com)\]

I will explain both Windows and Ubuntu Linux below. Follow only the section matching the computer you are using.

## 4\. Step 3A - Restore the microSD card using Windows 10 or Windows 11

For Windows, you can use a disk-imaging utility such as [sourceforge.net](https://sourceforge.net/projects/win32diskimager/?utm_source=chatgpt.com) to write your saved `.img` file to the card. \[[How to Guide](https://win32diskimager.net/docs/?utm_source=chatgpt.com); [UBOS - Open-source software for a thriving open social web \| Writing an image to a USB stick or SD card on Windows](https://ubos.net/docs/gears/faq-howto-troubleshooting/writing-image/windows/?utm_source=chatgpt.com)\]

### 4.1 Connect the replacement microSD card

1. Shut down the Jetson if it is still running.
2. Remove the microSD card from the Jetson, if necessary.
3. Insert the replacement card into your USB card reader.
4. Connect the reader to your Windows computer.
5. Wait for Windows to detect it.

Windows might display a message such as\:

> You need to format the disk in drive E: before you can use it.

Click **Cancel**\.

This message can appear because Windows does not natively recognize the Linux filesystems on your Jetson card. Do not format the card.

### 4.2 Identify the correct card

Press `Win + X` and select **Disk Management**\.

Inspect the newly connected removable disk. Confirm its capacity and ensure it corresponds to your microSD card.

For example, you might see a removable disk of approximately 119 GB for a card marketed as 128 GB.

Do not rely only on the drive letter. The letter can change when you reconnect the card.

Close Disk Management after you have identified the card. Do not delete or format any partitions.

### 4.3 Open Win32 Disk Imager

1. Install Win32 Disk Imager from its official project page.
2. Launch the application with administrator privileges if required.
3. Find the **Image File** field.
4. Click its browse button.
5. Select your saved `jetson-orin-nano-ubuntu22.img` file.

Make sure you selected your backup image, not an image you downloaded for a fresh installation. The purpose here is to recover your existing environment.

### 4.4 Select the destination device

In the application's **Device** selector, choose the drive letter corresponding to the replacement microSD card.

Check all three details\:

- The drive letter matches the card you identified.
- The capacity matches the expected card.
- You are not selecting a different USB drive or internal storage device.

If you cannot confidently identify the correct device, stop before writing.

### 4.5 Write the image
[![HDD消去ツールwipe-outの使い方](https://images.openai.com/static-rsc-4/v4FF8SqVgJpP0q5JlLW0KYyIA69dE26iN7IqhjxYnHB3U6qnoiJH2Y2anbZtBaRZjsxh4v_O-1dryQqfTkFCy2csKgiDM6f9sxp5Rp38U2XcVdS1fXpqrEi-yIbyyh9SSenm_G0125sVhPQclvSI27rvmY3evwtL2bqVyMwJFaMghiVx8oIB5vgevQDiA7N_?purpose=fullsize)](https://monomonotech.jp/kurage/memo/m220119_wipe_out.html)

Once you have verified the image and destination\:

1. Click **Write**\.
2. Read the confirmation dialog.
3. Confirm only if the selected device is definitely your intended microSD card.
4. Wait while the image is written.
5. Do not remove the card or disconnect the reader during the operation.

The write operation replaces the card's existing contents with the contents of your saved image.

The time required depends on the image size, reader speed and card performance. A large image may take many minutes.

If the application reports an error, do not assume that the card is usable.

### 4.6 Verify the write

If your version of the imaging tool provides a verification function, use it to compare the written card against the image. Otherwise, you can read the card back into a separate image file and compare its checksum, provided you have enough free storage.

Do not compare the SHA-256 of the entire physical card directly to the SHA-256 of the image file unless you know the card's readable byte capacity is exactly the image's byte length. A larger replacement card may contain extra bytes beyond the original image.

### 4.7 Safely eject the card

When writing and verification have finished\:

1. Close the imaging utility.
2. Use Windows' **Safely Remove Hardware** option if available.
3. Wait until the card reader can be disconnected safely.
4. Remove the microSD card.

Windows may again ask you to format the card because it sees Linux partitions. Click **Cancel**\.

Your card is now ready for the Jetson boot test.

---

## 5\. Step 3B - Restore the microSD card using Ubuntu Linux

Use this procedure instead if your host computer runs Ubuntu Linux.

### 5.1 Connect the replacement card

Insert the card into the reader and connect it to the host.

Open Terminal and run\:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS,MODEL
```

Compare the output with the list of devices before the card was inserted, if available.

Identify the replacement microSD card by its capacity and model.

For example, suppose the replacement card is confirmed as `/dev/sdb`\. This is an example only; your device may have a different name.

### 5.2 Check the destination carefully

Run\:

```bash
lsblk /dev/sdb
```

Verify that `/dev/sdb` is the whole card, with partitions beneath it.

The whole-device name looks like\:

```text
/dev/sdb
```

A partition name looks like\:

```text
/dev/sdb1
```

For restoring a full raw image, the destination must be the whole device, not one of its partitions.

**Never proceed if you are unsure which disk is the microSD card.** The next operation overwrites the destination device.

### 5.3 Unmount the card's partitions

Inspect its mount points\:

```bash
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINTS /dev/sdb
```

Unmount each mounted partition belonging to the card. For example\:

```bash
sudo umount /dev/sdb1
```

Only run that example if `/dev/sdb1` is actually a mounted partition of the confirmed replacement card.

Repeat for other mounted partitions belonging to the same card.

### 5.4 Write the saved image

Assuming the image is at the example path below and the confirmed target is `/dev/sdb`, run\:

```bash
sudo dd \
  if=/media/host/Backup/JetsonImages/jetson-orin-nano-ubuntu22.img \
  of=/dev/sdb \
  bs=4M status=progress conv=fsync
```

Replace the source path and destination device with your actual values.

Read the command carefully\:

- `if=` is the image file you are restoring from.
- `of=` is the replacement microSD card you are writing to.
- `bs=4M` sets the block size.
- `status=progress` displays progress.
- `conv=fsync` requests synchronization before completion.

Notice that the direction is now the opposite of the backup operation: the image file is the input, and the physical card is the output.

Wait until the command finishes and returns to the terminal prompt. If it reports a write error, do not proceed as if the restoration succeeded.

### 5.5 Synchronize and eject the card

Run\:

```bash
sync
```

Then safely eject the card using Ubuntu's file manager, or use an appropriate eject command after identifying the correct device.

Remove the card only after the write has completed and the operating system has finished accessing it.

## 6\. Step 4 - Put the restored microSD card into the Jetson

Now we will test whether the restored card can boot.

### 6.1 Prepare the Jetson

1. Make sure the Jetson Orin Nano is powered off.
2. Disconnect its power supply.
3. Insert the restored microSD card into the correct slot.
4. Reconnect the display, keyboard and mouse if you use them.
5. Reconnect the power supply.
6. Turn on the Jetson.

Do not insert or remove the card while the Jetson is powered on.

### 6.2 Observe the startup process

Watch the display.

You may see\:

- The NVIDIA startup screen.
- Boot messages.
- Ubuntu's login screen or initial setup screens.

The exact sequence depends on the image and whether Ubuntu has already been configured.

If Ubuntu starts normally, log in using the credentials associated with the restored installation.

### 6.3 Verify the operating system

Open Terminal and run\:

```bash
cat /etc/os-release
```

Confirm that the expected Ubuntu release is present.

Check the NVIDIA software release\:

```bash
cat /etc/nv_tegra_release
```

Check the kernel\:

```bash
uname -a
```

Then check the root filesystem\:

```bash
findmnt /
```

These checks help establish that the Jetson is running the expected system.

### 6.4 Check your development projects

Inspect your home directory\:

```bash
ls -lah "$HOME"
```

Check your robot SDK or project directories, for example\:

```bash
ls -lah "$HOME/Projects"
```

Use the actual path where your projects are stored.

Check that your expected tools are present\:

```bash
cmake --version
```

```bash
gcc --version
```

```bash
python3 --version
```

Some of these commands may fail if the original system did not have those tools installed or if the project used a different environment. That does not necessarily mean the restoration failed.

If you use a Python virtual environment, check it separately. For example\:

```bash
ls -lah "$HOME/robot_env"
```

Replace that path with your real environment directory.

### 6.5 Test networking and robot software

Check the network\:

```bash
ip address show
```

Check the relevant SDK files and configuration.

Before operating a physical robot, verify that its communication settings, safety limits and controller configuration are correct. Do not immediately run motor-control programs just because Ubuntu boots successfully.

---

## 7\. Step 5 - What if the Jetson does not boot?

Do not panic. A failed first boot does not automatically mean the backup is lost.

**Problem A - No display or no startup**

Check the power supply, card seating, card compatibility and boot indicators. Reinsert the card only after powering off.

---

**Problem B - Boot messages appear, but Ubuntu fails**

Record the messages. Check whether the image was written correctly and whether the replacement card has sufficient capacity.

---

**Problem C - Ubuntu starts but behaves incorrectly**

Check filesystem errors, NVIDIA software versions, project paths and Python dependencies.

---

**Problem D - The card appears correct but the board still cannot boot**

The Jetson may require a compatible boot firmware or recovery procedure. The microSD image does not include separate QSPI flash contents.

### 7.1 Check the image again

On the host computer, verify the saved image checksum again. If the checksum no longer matches, the image file may have changed or become corrupted.

### 7.2 Try a different card reader or replacement card

If writing or verification reported errors\:

1. Try a different USB port or card reader.
2. Repeat the write to a spare compatible microSD card.
3. Verify the write if your imaging tool supports it.
4. Test the new card in the Jetson.

Persistent write errors may indicate a failing or counterfeit card.

### 7.3 Understand the boot firmware limitation

A raw microSD image contains the data read from the card, not necessarily every component that the Jetson requires to start.

If the board's QSPI boot firmware is incompatible or corrupted, you may need NVIDIA's Jetson Linux recovery or flashing tools from a compatible Ubuntu host PC. NVIDIA documents backup and restore procedures separately from ordinary SD-card imaging. \[[Flashing Support — NVIDIA Jetson Linux Developer Guide 1 documentation](https://docs.nvidia.com/jetson/archives/r36.4/DeveloperGuide/SD/FlashingSupport.html?highlight=nvme&utm_source=chatgpt.com); [Jetson Orin Nano Developer Kit User Guide - Software Setup](https://developer.nvidia.com/embedded/learn/jetson-orin-nano-devkit-user-guide/software_setup.html?utm_source=chatgpt.com)\]

Do not randomly update or erase the QSPI firmware. First identify the JetPack/Jetson Linux release and follow the matching NVIDIA instructions.

---

## 8\. Step 6 - After a successful restoration

Once Ubuntu has booted and your projects are present\:

1. Check that the system date and time are correct.
2. Check the network and IP configuration.
3. Verify the installed NVIDIA software release.
4. Confirm that your development tools work.
5. Re-test your robot SDKs and application dependencies.
6. Keep the original backup image unchanged.
7. Make a new backup after you have confirmed the restored system works.

If your restored card is larger than the original card, the additional capacity might not automatically become available to Ubuntu. Check with\:

```bash
lsblk
```

and\:

```bash
df -h /
```

Do not resize partitions until you have confirmed that the restored system boots and you have a safe backup.

---

## 9\. Restoration checklist

## Restore progress

of

## 10\. Let me tailor the restoration instructions to your computer

I have provided both Windows and Ubuntu methods. To help you avoid selecting the wrong disk, tell me which computer you will use to restore the image.

1\. Your host computer

Windows 10 or Windows 11

Ubuntu Linux

Another operating system

---

2\. Which card will you restore?

A new or replacement microSD card

The original microSD card

---

3\. Have you already created the `.img` backup file?

Yes, the backup image is ready

No, I still need to create it

[Show my exact restoration steps]

## Prompt:
10/26/2026, 1:50:40 AM

and in the process which program is used?

## Response:
10/26/2026, 1:50:41 AM · gpt-6-mini

For backing up your Ubuntu 22.04 system on the **Jetson Orin Nano booting from a microSD card**, the program you use depends on whether the computer performing the backup runs Windows or Ubuntu.

Since you selected **Method B: Full Storage Image**, we want to create an exact image file of the entire microSD card, such as `jetson_orin_nano_backup.img`\.

## 1\. Which program should you use?

[![How to clone SD cards on Windows](https://images.openai.com/static-rsc-4/mlPHf0VdmYCx7TeQps-7yxQcOSbD1b5qHiLT0D6VQwbD04uS9rX5-H4NtBIS7v58uJ5Z3FL-s178O7nZeCDgELoEwwypeYPbNn8xSz4FFK2Uw8keROhnjihP1YtUTGHilQOs4mTgWOKtHP4KvNzazeT6b7JhbODTyj7yhxdXrJKfsFVRpI7-lnnEyWVYI1du?purpose=fullsize)](https://emteria.com/kb/clone-sd-cards-windows)

**Option A - Win32 Disk Imager (Windows)**

(Recommended if your PC runs Windows)

This program can read the entire microSD card into an `.img` backup file and write that image back to a card later.

Download: [Win32 Disk Imager official project page](https://sourceforge.net/projects/win32diskimager/?utm_source=chatgpt.com)

---

[![How to Clone Hard Disk Partition with Ubuntu Live USB](https://images.openai.com/static-rsc-4/rqaoJYbf_GvZLVl5q22P3JJsZHheBHqsyG8mKYMJNv8-p_AEoJ8bDNc668n5jssDQnj5Jgoq_ljaVQBzW_K7Az7ENPrQ_N32T1uiBvD_49FPKlH4_4fPv21uMieejdncXDjUVI-lloqtGMsqUi4zf07ChDf-UolUMS1Fsr2ODx2zxRroqqqLDka29dzdAoL3?purpose=fullsize)](https://www.addictivetips.com/windows-tips/create-disk-image-clone-hard-disk-partition-with-ubuntu-live-usb/)

**Option B - `dd` \(Ubuntu/Linux)**

`dd` is a command-line program already included in most Ubuntu installations. It can copy the entire microSD card into an image file and restore it later.

Example backup command\:

```bash
sudo dd if=/dev/sdX of=jetson_backup.img bs=4M status=progress conv=fsync
```

**Important\:** Replace `/dev/sdX` with the confirmed name of your microSD card. The example is not a device name to copy blindly.

## 2\. What does each program do?

| Task | Windows PC | Ubuntu PC |
|--------|--------|--------|
| Create full-card image | Win32 Disk Imager - **Read** | `dd` command |
| Restore image to card | Win32 Disk Imager - **Write** | `dd` command |
| Verify image checksum | PowerShell `Get-FileHash` | `sha256sum` |

The **Read** and **Write** labels in Win32 Disk Imager are important: **Read** copies the card into a backup file; **Write** overwrites a card with an existing backup image.

## 3\. Let’s choose the correct procedure

One question first: **Is the computer you will use to back up the Jetson’s microSD card running Windows 10/11 or Ubuntu Linux?**



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)